package com.books.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.books.shoppingcart.model.User;
@Controller
public class BookController {
	/*@RequestMapping("/")
	public String test()
	{
		
		System.out.println("inside index controller");
		return "index";
	}*/
	@RequestMapping("/front")
	public ModelAndView view()
	{
		ModelAndView mav = new ModelAndView("front");
		User user = new User();
		mav.getModelMap().put("front", user);
		System.out.println("front clicked..");
		return mav;
	}
	
	@RequestMapping("/Login")
	public String showlogin()
	{
		System.out.println("inside login controller");
		return "Login";
	}
	@RequestMapping("/logout")
	public String showlogout()
	{
		System.out.println("inside login controller");
		return "front";
	}
	@RequestMapping("/Registration")
	public String showregister()
	{
		System.out.println("inside registration controller");
		return "Registration";
	}
	@RequestMapping("/genre")
	public String showgenre()
	{
		System.out.println("inside registration controller");
		return "genre";
	}
	@RequestMapping("/raven")
	public String showraven()
	{
		System.out.println("inside registration controller");
		return "raven";
	}
	@RequestMapping("/outlier")
	public String showoutlier()
	{
		System.out.println("inside registration controller");
		return "outlier";
	}
	@RequestMapping("/admin")
	public String showadmin()
	{
		System.out.println("inside Admin Home controller");
		return "adminHome";
	}
	
}
