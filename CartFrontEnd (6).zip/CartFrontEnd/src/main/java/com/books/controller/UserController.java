
	package com.books.controller;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.servlet.ModelAndView;

	import com.books.shoppingcart.dao.UserDAO;
import com.books.shoppingcart.model.User;


	@Controller
	public class UserController {
		 @Autowired
			UserDAO userDAO;


		 @RequestMapping("/isValidUser")
			public ModelAndView showMessage(@RequestParam(value = "name") String name,
					@RequestParam(value = "password") String password) {
				System.out.println("in validation controller");

				String message;
				ModelAndView mv ;
				if (userDAO.isValidUser(name, password,true)) 
				{
					message = "Valid credentials";
					 mv = new ModelAndView("adminHome");
				} else {
					message = "Invalid credentials";
					 mv = new ModelAndView("Login");
				}

				//ModelAndView mv = new ModelAndView("success");
				mv.addObject("message", message);
				mv.addObject("name", name);
				// mv.addObject("password", password);
				return mv;
			}
		 @RequestMapping("/register")
			public ModelAndView registerUser(@ModelAttribute User user){
				userDAO.saveorUpdate(user);
				return new ModelAndView("userHome");
				
			}

	}



