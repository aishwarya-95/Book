package com.contacts;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ContactsControllers
{
	@RequestMapping("/hyperion")
	public String hyper()
	{
		System.out.println("faq has been clicked..");
		return "hyperion";
	}
	@RequestMapping("/faq")
	public String go()
	{
		System.out.println("faq has been clicked..");
		return "faq";
	}
	@RequestMapping("/contact")
	public String move()
	{
		System.out.println("contact clicked..");
		return "contact_us";
	}
	@RequestMapping("/home")
	public ModelAndView view()
	{
		ModelAndView mav = new ModelAndView("home");
		User user = new User();
		mav.getModelMap().put("home", user);
		System.out.println("home clicked..");
		return mav;
	}
	@RequestMapping("/userName")
	public String home()
	{
		System.out.println("login clicked");
		return "home";
	}
	@RequestMapping("/password")
	public String pass()
	{
		return "home";
	}
	@RequestMapping("/About")
	public String show()
	{
		System.out.println("inside controller");
		return "about_us";
	}
	@RequestMapping("/register")
	public String greeting()
	{
		System.out.println("inside controller");
		return "Registration";
	}
	/*@RequestMapping("/login")
	public String msg()
	{
		System.out.println("inside controller");
		return "login";
	}*/
	@RequestMapping("/test")
	public String test()
	{
		System.out.println("inside controller");
		return "test";
	}
	@RequestMapping(value="/welcome", method=RequestMethod.GET)
	public String welcome()
	{
		System.out.println("inside welcome controller");
		return "welcome";
	}
	
	@Autowired
	private ContactFormValidator validator;
	
	
	@InitBinder
	public void initBinder(WebDataBinder binder) 
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
		
	
	
	@RequestMapping(value="/userLogin", method=RequestMethod.POST)
	public String create(@ModelAttribute("home")User user, BindingResult result, SessionStatus status)
	{
		
		System.out.println(user);
		validator.validate(user, result);
		if (result.hasErrors()) 
		{				
			return "home";
		}
//		contactsDAO.save(contact);
		status.setComplete();
		return "home";
	}
	
	
	
}
