function clickTest(){
	alert('hiii');
}