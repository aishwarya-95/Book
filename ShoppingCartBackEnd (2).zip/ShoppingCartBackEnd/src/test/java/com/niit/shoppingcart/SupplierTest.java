package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class SupplierTest {
	 public static void main(String[] args){
		 @SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart"); 
		context.refresh();
		
		SupplierDAO SupplierDAO = (SupplierDAO) context.getBean("SupplierDAO");
		
		Supplier Supplier = (Supplier) context.getBean("Supplier");
		Supplier.setId("SP100");
		Supplier.setName("SPname");
		Supplier.setAddress("SPaddress");
		
		SupplierDAO.saveOrUpdate(Supplier);
		
		if(SupplierDAO.get("sdfsf") ==null)
		{
			System.out.println("Supplier does not exist");
		}
		else
		{
			System.out.println("Supplier exist...the details are...");
			System.out.println();
		}
	 }

}
