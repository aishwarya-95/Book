package com.books.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class BookController {
	@RequestMapping("/")
	public String test()
	{
		
		System.out.println("inside index controller");
		return "index";
	}
	@RequestMapping("/aboutus")
	public String showaboutus()
	{
		System.out.println("inside about controller");
		return "aboutus";
	}
	@RequestMapping("/Login")
	public String showlogin()
	{
		System.out.println("inside login controller");
		return "Login";
	}
	@RequestMapping("/Registration")
	public String showregister()
	{
		System.out.println("inside registration controller");
		return "Registration";
	}
	@RequestMapping("/contactus")
	public String showcontact()
	{
		System.out.println("inside contact controller");
		return "contactus";
	}
}
