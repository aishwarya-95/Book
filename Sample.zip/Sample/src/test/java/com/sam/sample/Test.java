package com.sam.sample;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
  public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	
	context.scan("com.sam.sample");
	context.refresh();
	context.getBean("category");
	
	System.out.println("Category is created");
}
}
