package com.books.shoppingcart.dao;

import java.util.List;

import com.books.shoppingcart.model.Cart;

public interface CartDAO {
	
	public List<Cart> list(String id);
	public Cart get(String id);
	public void saveorUpdate(Cart cart);
	public String delete(String id);
	public Long getTotalAmount(String id);
	

}
