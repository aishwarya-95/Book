package com.books.shoppingcart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
    @Entity
	@Table(name="USER_DETAILS")
	@Component

		
	public class User {	
		
		private String id;
		private String password;
		private String isAdmin;
	
		
		
		@Id
		@Column(name="ID")
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
		
		@Column(name="PASSWORD")
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		@Column(name="ADMIN")
		public String getIsAdmin() {
			return isAdmin;
		}
		public void setIsAdmin(String isAdmin) {
			this.isAdmin = isAdmin;
		}
		
		
		
		
		
	}