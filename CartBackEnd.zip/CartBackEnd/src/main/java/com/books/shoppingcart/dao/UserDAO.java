package com.books.shoppingcart.dao;

import java.util.List;

import com.books.shoppingcart.model.User;



public interface UserDAO {
	public List<User> list();
	public User get(String id);
	public void saveorUpdate(User user);
	
	public void delete(String id);
	public boolean isValidUser(String id, String name, boolean isAdmin);
	
	
}



