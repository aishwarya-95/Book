package com.books.shoppingcart.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.books.shoppingcart.model.Cart;

@Repository("cartDAO")
public class CartDAOimpl  implements CartDAO{
	@Autowired
	private SessionFactory sessionFactory;

	public CartDAOimpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Cart> list() {
		@SuppressWarnings("unchecked")
		List<Cart> list = (List<Cart>)
		     sessionFactory.getCurrentSession()
		     .createCriteria(Cart.class)
		     .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
}
	
		

	@Transactional
	public Cart get(int id) {
		String hql = "from Cart where id=" + "'" + id + "'  and status = " + "0";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<Cart> list = (List<Cart>) query.list();

		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}		
		return null;
	}
	
	@Transactional
	public Cart getProductsUsingProductIdAndUserId(String productId,String userSessionId) {
		String hql = "from Cart where productId=" + "'" + productId + "' and sessionUserId = '" + userSessionId+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<Cart> list = (List<Cart>) query.list();

		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}		
		return null;
	}

	@Transactional
	public void saveOrUpdate(Cart cart) {
		sessionFactory.getCurrentSession().saveOrUpdate(cart);		
	}

	@Transactional
	public String delete(String id) {
		Cart cart = new Cart();
		cart.setid(Integer.parseInt(id));//cart unique id has to be given here
		try {
			sessionFactory.getCurrentSession().delete(cart);
		} catch (HibernateException e) {
			e.printStackTrace();
			return e.getMessage();

		}		
		return null;
	}
	
	@Transactional

	public Long getTotalAmount(String id) {
		String hql = "sum(price) from Cart where id = " + "'" + id + "'" + "and status = '" + "N" + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		Long sum=(Long)query.uniqueResult();
		/*query.executeUpdate();
		return query.getFirstResult();*/  // Need to check
		
		return sum;

	}
}
