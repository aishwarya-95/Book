package com.books.shoppingcart.dao;

import java.util.List;

import com.books.shoppingcart.model.Product;



public interface ProductDAO {
	
	public List<Product> list();
	public Product get(String id);
	public void saveorUpdate(Product product);
	
	public void delete(String id);
	
}
