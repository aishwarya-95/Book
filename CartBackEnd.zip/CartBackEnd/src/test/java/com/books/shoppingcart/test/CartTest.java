package com.books.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.CartDAO;
import com.books.shoppingcart.model.Cart;

public class CartTest {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
		
		Cart cart = (Cart) context.getBean("cart");

	    CartDAO cartDAO = (CartDAO)  context.getBean("cartDAO");
	    
	    
	    cart.setId("OG120");
	    cart.setName("OGNAME120");
	    cart.setDescription("OGDESC120");

	   
	    cartDAO.saveorUpdate(cart);
	  




}
}