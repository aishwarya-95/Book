package com.books.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.ProductDAO;
import com.books.shoppingcart.model.Product;

public class ProductTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.books.*");
	context.refresh();
	
	Product product = (Product) context.getBean("product");
	
    ProductDAO productDAO = (ProductDAO)  context.getBean("productDAO");

    product.setId("OG123");
    product.setName("OGNAME123");
    product.setDescription("OGDESC123");
    product.setPrice("OGPRICE123");
    
    productDAO.saveorUpdate(product);
    
	
}
}
