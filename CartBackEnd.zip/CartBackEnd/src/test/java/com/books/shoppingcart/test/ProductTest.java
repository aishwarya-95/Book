package com.books.shoppingcart.test;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.ProductDAO;
import com.books.shoppingcart.model.Product;

public class ProductTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.books.*");
	context.refresh();
	
	Product product = (Product) context.getBean("product");
	
    ProductDAO productDAO = (ProductDAO)  context.getBean("productDAO");
   /* 
    File file = new File("C:\\Users\\Aishu\\workspace4\\CartBackEnd\\src\\images\\a-walk-to-remember.jpg");
    
            byte[] bFile = new byte[(int) file.length()];
    
     
    
            try {
    
             FileInputStream fileInputStream = new FileInputStream(file);
    
             fileInputStream.read(bFile);
    
             fileInputStream.close();
    
            } catch (Exception e) {
    
             e.printStackTrace();
    
            }*/
   
     

    product.setId("B100");
   
    product.setName("Walk to remember");
    product.setDescription("Romantic Drama");
   
    product.setPrice("350");
    
    productDAO.saveorUpdate(product);
    
    

   /* product.setId("B250");
    product.setCategory_id("102");
    product.setName("Harry Potter and the cursed child");
    product.setDescription("Fantasy");
    product.setPrice("750");
    product.setSupplier_id("103");
    productDAO.saveorUpdate(product);
    */

   /* product.setId("B200");
    product.setCategory_id("100");
    product.setName("Vampire Academy");
    product.setDescription("Young Adult Fiction");
    product.setSupplier_id("105");
    product.setPrice("500");
    
    productDAO.saveorUpdate(product);*/
    
	
}
}
