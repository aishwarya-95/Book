package com.books.shoppingcart.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.books.shoppingcart.dao.UserDAO;
import com.books.shoppingcart.model.Category;
import com.books.shoppingcart.model.User;


public class Test {
	
	
	static AnnotationConfigApplicationContext context;
	
	public static void main(String[] args) {
	
		context = new AnnotationConfigApplicationContext();
		context.scan("com.books.shoppingcart");
		context.refresh();

	
	
		
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		User user = new User();
		user.setId("Aishwarya");
		user.setPassword("patrice");
		user.setAdmin(true);
		userDAO.saveOrUpdate(user);
		user.setId("Nivei");
		user.setPassword("pat");
		user.setAdmin(false);
		
		userDAO.saveOrUpdate(user);
		user.setId("Charlie");
		user.setPassword("bohimian");
		user.setAdmin(false);
		
		userDAO.saveOrUpdate(user);
		user.setId("Traviz");
		user.setPassword("jules");
		user.setAdmin(false);
		
		userDAO.saveOrUpdate(user);
		
		
		
		
		
		
	}

	

}
