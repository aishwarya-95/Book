package com.books.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.SupplierDAO;
import com.books.shoppingcart.model.Supplier;

public class SupplierTest {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
		
		Supplier supplier = (Supplier) context.getBean("supplier");
	
	    SupplierDAO supplierDAO = (SupplierDAO)  context.getBean("supplierDAO");
	    
	    
	    supplier.setId("OG125");
        supplier.setName("OGNAME125");
        supplier.setAddress("OGDESC125");

       
        supplierDAO.saveorUpdate(supplier);
       




}


}

