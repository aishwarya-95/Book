package com.books.shoppingcart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.SupplierDAO;
import com.books.shoppingcart.model.Supplier;

public class SupplierTest {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.books.shoppingcart");
		context.refresh();
		
		Supplier Supplier = (Supplier) context.getBean("supplier");
	
	    SupplierDAO SupplierDAO = (SupplierDAO)  context.getBean("supplierDAO");
	    
	    
	   
        Supplier.setId("101");
        Supplier.setName("Harper collins");
        Supplier.setAddress("Mumbai");

       
        SupplierDAO.saveorUpdate(Supplier);
       


 }

}
