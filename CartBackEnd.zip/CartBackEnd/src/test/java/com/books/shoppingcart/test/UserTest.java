package com.books.shoppingcart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.UserDAO;
import com.books.shoppingcart.model.User;




public class UserTest {
	
	static AnnotationConfigApplicationContext context;
	
	public UserTest()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
	}
	
	public static void createUser(User user)
	{
		
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		userDAO.saveorUpdate(user);
		
		
	}
	public static void main(String[] args) {
		UserTest t=new UserTest();
		User user = (User) context.getBean("user");
		user.setId("NIIT");
		user.setPassword("NIIT");
		user.setIsAdmin("true");
		t.createUser(user);
		
		UserTest m=new UserTest();
		User user1 = (User) context.getBean("user");
		user.setId("Travis");
		user.setPassword("blue");
		user.setIsAdmin("false");
		t.createUser(user);
		
		
		
	}

	

}
