package com.books.shoppingcart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.UserDAO;
import com.books.shoppingcart.model.User;




public class UserTest {
	
	static AnnotationConfigApplicationContext context;
	
	public UserTest()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
	}
	
	public static void createUser(User user)
	{
		
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		userDAO.saveorUpdate(user);
		
		
	}
	public static void main(String[] args) {
		UserTest t=new UserTest();
		User user = (User) context.getBean("user");
		user.setId("A100");
		user.setPassword("NIIT");
		user.setName("Aishwarya");
		user.setEmail("s.aishwarya95@gmail.com");
		user.setAddress("chennai");
		user.setMobile("9442920184");
		user.setAdmin(true);
		
		t.createUser(user);
		
		/*UserTest m=new UserTest();
		User user1 = (User) context.getBean("user");
		user.setId("U100");
		user.setPassword("patrice");
		user.setName("LAKSHMI");
		user.setEmail("lakshmi@gmail.com");
		user.setAddress("Tirunelveli");
		user.setMobile("9487920184");
		user.setAdmin(false);
		
		t.createUser(user);*/
		
		
		
	}

	

}
