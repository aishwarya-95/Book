package com.books.shoppingcart.test;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.books.shoppingcart.dao.CategoryDAO;
import com.books.shoppingcart.model.Category;

public class CategoryTest {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.books.*");
		context.refresh();
		
		Category category = (Category) context.getBean("category");
	
	    CategoryDAO categoryDAO = (CategoryDAO)  context.getBean("categoryDAO");
	    
	    
	    category.setId("OG125");
        category.setName("OGNAME125");
        category.setDescription("OGDESC125");

       
        categoryDAO.saveorUpdate(category);
       



}


}