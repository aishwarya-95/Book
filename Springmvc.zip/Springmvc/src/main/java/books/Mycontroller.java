package books;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Mycontroller {
	@RequestMapping("/welcome")
public ModelAndView showMsg()
{
		String greetingMsg = "Hi!";
	return new ModelAndView("welcome","message",greetingMsg);
}
}
